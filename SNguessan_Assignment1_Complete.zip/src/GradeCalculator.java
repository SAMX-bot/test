import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Scanner;

/*
 * Class: CMSC203
 * Instructor: A.tarek
 * Description: Grade Calculator - reads a course configuration file and a
 *              student scores file, validates all input, computes a
 *              weighted overall average and letter grade (with optional
 *              +/- modifiers), and writes a summary report to a file.
 * Due: MM/DD/YYYY
 * Note: all Scanners and printf calls use Locale.US so that scores written
 *       with a decimal point (95.0) are read and displayed correctly on a
 *       computer whose regional settings use a decimal comma.
 * Platform/compiler: (fill in, e.g. Eclipse / JDK 21)
 * I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or
 * any source. I have not given my code to any student.
 * Print your Name here: Samuel-Andre nguessan
 */
public class GradeCalculator {

    public static void main(String[] args) {

        // ---------- Constants ----------
        final String CONFIG_FILE_NAME = "gradeconfig.txt";
        final String INPUT_FILE_NAME = "grades_input.txt";
        final String OUTPUT_FILE_NAME = "grades_report.txt";
        final int REQUIRED_WEIGHT_TOTAL = 100;

        // Default configuration used when gradeconfig.txt is missing/invalid.
        final String DEFAULT_COURSE_NAME = "CMSC203 Computer Science I";
        final int DEFAULT_NUM_CATEGORIES = 3;
        final String DEFAULT_CATEGORY_1_NAME = "Projects";
        final int DEFAULT_CATEGORY_1_WEIGHT = 40;
        final String DEFAULT_CATEGORY_2_NAME = "Quizzes";
        final int DEFAULT_CATEGORY_2_WEIGHT = 30;
        final String DEFAULT_CATEGORY_3_NAME = "Exams";
        final int DEFAULT_CATEGORY_3_WEIGHT = 30;

        System.out.println("========================================");
        System.out.println("   CMSC203 Project 1 - Grade Calculator");
        System.out.println("========================================");

        // ---------- 1. Load and validate the configuration file ----------
        // (Read once, purely to VALIDATE it: file exists, numbers parse, and
        //  the category weights add up to exactly 100. No category data is
        //  stored here - it is re-read on demand in the processing loop
        //  below, since arrays/ArrayLists are not allowed.)
        System.out.println("Loading configuration from " + CONFIG_FILE_NAME + " ...");

        String courseName;
        int numCategories;
        boolean usedDefaultConfig;

        boolean configValid = true;
        String configCourseName = null;
        int configNumCategories = 0;
        int weightSum = 0;

        Scanner configValidationScanner = null;
        try {
            configValidationScanner = new Scanner(new File(CONFIG_FILE_NAME));
            configValidationScanner.useLocale(Locale.US);

            configCourseName = configValidationScanner.nextLine().trim();
            configNumCategories = Integer.parseInt(configValidationScanner.nextLine().trim());

            if (configCourseName.isEmpty() || configNumCategories <= 0) {
                configValid = false;
            }

            int categoriesChecked = 0;
            while (configValid && categoriesChecked < configNumCategories) {
                if (!configValidationScanner.hasNext()) {
                    configValid = false;
                    break;
                }
                configValidationScanner.next(); // category name (not stored in this pass)

                if (!configValidationScanner.hasNextInt()) {
                    configValid = false;
                    break;
                }
                weightSum += configValidationScanner.nextInt();

                if (configValidationScanner.hasNextLine()) {
                    configValidationScanner.nextLine();
                }
                categoriesChecked++;
            }

            if (configValid && weightSum != REQUIRED_WEIGHT_TOTAL) {
                configValid = false;
            }

        } catch (FileNotFoundException e) {
            configValid = false;
        } catch (NumberFormatException e) {
            configValid = false;
        } catch (NoSuchElementException e) {
            configValid = false;
        } finally {
            if (configValidationScanner != null) {
                configValidationScanner.close();
            }
        }

        if (configValid) {
            courseName = configCourseName;
            numCategories = configNumCategories;
            usedDefaultConfig = false;
            System.out.println("Configuration loaded successfully.");
        } else {
            courseName = DEFAULT_COURSE_NAME;
            numCategories = DEFAULT_NUM_CATEGORIES;
            usedDefaultConfig = true;
            System.out.println("Configuration file missing or invalid.");
            System.out.println("Using default configuration: Projects 40 / Quizzes 30 / Exams 30.");
        }

        // ---------- 2. Open the student scores input file ----------
        System.out.println("Using input file: " + INPUT_FILE_NAME);
        System.out.println("Using output file: " + OUTPUT_FILE_NAME);

        Scanner inputFileScanner;
        try {
            inputFileScanner = new Scanner(new File(INPUT_FILE_NAME));
            inputFileScanner.useLocale(Locale.US);
        } catch (FileNotFoundException e) {
            System.out.println("Error: input file \"" + INPUT_FILE_NAME + "\" was not found. Exiting.");
            System.out.println("Program complete. Goodbye!");
            return;
        }

        if (!inputFileScanner.hasNextLine()) {
            System.out.println("Error: input file \"" + INPUT_FILE_NAME + "\" is empty or unreadable. Exiting.");
            inputFileScanner.close();
            return;
        }

        System.out.println("Reading student scores...");

        String studentFirstName = inputFileScanner.nextLine().trim();
        String studentLastName = inputFileScanner.hasNextLine() ? inputFileScanner.nextLine().trim() : "";

        if (studentFirstName.isEmpty() || studentLastName.isEmpty()) {
            System.out.println("Error: student name could not be read from the input file. Exiting.");
            inputFileScanner.close();
            return;
        }

        System.out.println("Student: " + studentFirstName + " " + studentLastName);
        System.out.println("Course: " + courseName);
        System.out.println("Category Results:");

        // ---------- 3. Open the report file (written to as we go) ----------
        PrintWriter reportWriter = null;
        try {
            reportWriter = new PrintWriter(new FileWriter(OUTPUT_FILE_NAME));
        } catch (IOException e) {
            System.out.println("Warning: could not open \"" + OUTPUT_FILE_NAME + "\" for writing. "
                    + "Continuing with console output only.");
        }

        if (reportWriter != null) {
            reportWriter.println("========================================");
            reportWriter.println("   CMSC203 Project 1 - Grade Calculator");
            reportWriter.println("========================================");
            reportWriter.println("Course: " + courseName);
            reportWriter.println("Student: " + studentFirstName + " " + studentLastName);
            reportWriter.println("Configuration used: "
                    + (usedDefaultConfig ? "DEFAULT (config file missing or invalid)" : CONFIG_FILE_NAME));
            reportWriter.println();
            reportWriter.println("Category Results:");
        }

        // ---------- 4. Process each category (config + input in lock-step) ----------
        double overallAverage = 0.0;
        int categoryIndex = 1;

        while (categoryIndex <= numCategories) {

            // -- Determine this category's name and weight from the configuration --
            String categoryName;
            int categoryWeight;

            if (usedDefaultConfig) {
                if (categoryIndex == 1) {
                    categoryName = DEFAULT_CATEGORY_1_NAME;
                    categoryWeight = DEFAULT_CATEGORY_1_WEIGHT;
                } else if (categoryIndex == 2) {
                    categoryName = DEFAULT_CATEGORY_2_NAME;
                    categoryWeight = DEFAULT_CATEGORY_2_WEIGHT;
                } else {
                    categoryName = DEFAULT_CATEGORY_3_NAME;
                    categoryWeight = DEFAULT_CATEGORY_3_WEIGHT;
                }
            } else {
                // Re-open the config file and skip ahead to the category we need.
                // (No arrays are used to "remember" earlier categories - each
                //  pass just walks the file again from the top.)
                String lookupName = "";
                int lookupWeight = 0;
                try {
                    Scanner categoryLookupScanner = new Scanner(new File(CONFIG_FILE_NAME));
                    categoryLookupScanner.useLocale(Locale.US);
                    categoryLookupScanner.nextLine(); // course name
                    categoryLookupScanner.nextLine(); // category count

                    int skip = 1;
                    while (skip < categoryIndex) {
                        categoryLookupScanner.next();
                        categoryLookupScanner.nextInt();
                        if (categoryLookupScanner.hasNextLine()) {
                            categoryLookupScanner.nextLine();
                        }
                        skip++;
                    }
                    lookupName = categoryLookupScanner.next();
                    lookupWeight = categoryLookupScanner.nextInt();
                    categoryLookupScanner.close();
                } catch (IOException e) {
                    lookupName = "Unknown";
                    lookupWeight = 0;
                }
                categoryName = lookupName;
                categoryWeight = lookupWeight;
            }

            // -- Read the matching category block from the student input file --
            if (!inputFileScanner.hasNext()) {
                System.out.println("Error: expected data for category \"" + categoryName
                        + "\" but the input file ended early.");
                if (reportWriter != null) {
                    reportWriter.println("  " + categoryName + ": ERROR - no data found in input file.");
                }
                break;
            }

            String categoryNameFromInput = inputFileScanner.next();
            boolean namesMatch = categoryNameFromInput.equalsIgnoreCase(categoryName);

            int scoreCount = 0;
            boolean haveCount = inputFileScanner.hasNextInt();
            if (haveCount) {
                scoreCount = inputFileScanner.nextInt();
            } else {
                System.out.println("Error: missing score count for category \"" + categoryNameFromInput + "\".");
            }

            double categoryTotal = 0.0;
            int scoresRead = 0;
            while (scoresRead < scoreCount) {
                if (inputFileScanner.hasNextDouble()) {
                    categoryTotal += inputFileScanner.nextDouble();
                    scoresRead++;
                } else if (inputFileScanner.hasNext()) {
                    System.out.println("Warning: skipping non-numeric score value in category \""
                            + categoryNameFromInput + "\".");
                    inputFileScanner.next();
                } else {
                    System.out.println("Error: not enough scores were provided for category \""
                            + categoryNameFromInput + "\".");
                    break;
                }
            }

            if (!namesMatch) {
                System.out.println("Error: category \"" + categoryNameFromInput
                        + "\" in the input file does not match configured category \"" + categoryName
                        + "\". Skipping this category.");
                if (reportWriter != null) {
                    reportWriter.println("  " + categoryName + ": SKIPPED (name mismatch in input file).");
                }
            } else if (scoresRead == 0) {
                System.out.println("Error: no valid scores were found for category \"" + categoryName
                        + "\". Skipping this category.");
                if (reportWriter != null) {
                    reportWriter.println("  " + categoryName + ": SKIPPED (no valid scores found).");
                }
            } else {
                double categoryAverage = categoryTotal / scoresRead;
                double contribution = categoryAverage * categoryWeight / 100.0;
                overallAverage += contribution;

                System.out.printf(Locale.US, "  %s (%d%%): average = %.2f%n", categoryName, categoryWeight, categoryAverage);
                if (reportWriter != null) {
                    reportWriter.printf(Locale.US, "  %s (%d%%): average = %.2f%n", categoryName, categoryWeight, categoryAverage);
                }
            }

            categoryIndex++;
        }

        inputFileScanner.close();

        // ---------- 5. Determine the base letter grade (switch on grade band) ----------
        int gradeBand = (int) (overallAverage / 10.0);
        char baseLetter;

        switch (gradeBand) {
            case 10:
            case 9:
                baseLetter = 'A';
                break;
            case 8:
                baseLetter = 'B';
                break;
            case 7:
                baseLetter = 'C';
                break;
            case 6:
                baseLetter = 'D';
                break;
            default:
                baseLetter = 'F';
                break;
        }

        System.out.printf(Locale.US, "Overall numeric average: %.2f%n", overallAverage);
        System.out.println("Base letter grade: " + baseLetter);

        // ---------- 6. Prompt for +/- grading (validated keyboard input loop) ----------
        Scanner keyboard = new Scanner(System.in);
        String plusMinusChoice = "";
        boolean validChoice = false;

        do {
            System.out.print("Apply +/- grading? (Y/N): ");
            if (keyboard.hasNextLine()) {
                plusMinusChoice = keyboard.nextLine().trim();
            } else {
                plusMinusChoice = "";
            }

            if (plusMinusChoice.equalsIgnoreCase("Y") || plusMinusChoice.equalsIgnoreCase("N")) {
                validChoice = true;
            } else {
                System.out.println("Invalid input. Please enter Y or N.");
            }
        } while (!validChoice);

        boolean applyPlusMinus = plusMinusChoice.equalsIgnoreCase("Y");

        // ---------- 7. Apply +/- modifiers if requested ----------
        // Cutoffs (my own choice, documented here): within each 10-point band,
        // the TOP 3 points (band position >= 7) earn a "+", the BOTTOM 3 points
        // (band position < 3) earn a "-", and the middle 4 points are the plain
        // letter. "A" never gets a "+" (100 is the ceiling) and "F" never gets
        // a modifier at all.
        String finalLetterGrade;

        if (applyPlusMinus && baseLetter != 'F') {
            double bandPosition = overallAverage % 10.0;
            char modifier = ' ';

            if (baseLetter == 'A') {
                if (bandPosition < 3.0) {
                    modifier = '-';
                }
            } else {
                if (bandPosition >= 7.0) {
                    modifier = '+';
                } else if (bandPosition < 3.0) {
                    modifier = '-';
                }
            }

            if (modifier == ' ') {
                finalLetterGrade = String.valueOf(baseLetter);
            } else {
                finalLetterGrade = String.valueOf(baseLetter) + modifier;
            }
        } else {
            finalLetterGrade = String.valueOf(baseLetter);
        }

        System.out.println("Final letter grade: " + finalLetterGrade);

        // ---------- 8. Finish writing and close the report file ----------
        if (reportWriter != null) {
            reportWriter.println();
            reportWriter.printf(Locale.US, "Overall numeric average: %.2f%n", overallAverage);
            reportWriter.println("Base letter grade: " + baseLetter);
            reportWriter.println("Applied +/- grading: " + (applyPlusMinus ? "Yes" : "No"));
            reportWriter.println("Final letter grade: " + finalLetterGrade);
            reportWriter.close();
            System.out.println("Summary written to " + OUTPUT_FILE_NAME);
        }

        System.out.println("Program complete. Goodbye!");
    }
}
